package com.darkdims;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.world.biome.Biome;

public class Themes {
    public static final int DARK_ID = 101;

    public static class Theme {
        public final String name; public final Biome biome;
        public final IBlockState top, filler, fluid;
        public IBlockState stone = Blocks.STONE.getDefaultState();
        public final int base, amp, sea; public int fog = -1; public final boolean dark;
        Theme(String n, Biome b, IBlockState t, IBlockState f, IBlockState fl, int base, int amp, int sea, boolean dark) {
            name = n; biome = b; top = t; filler = f; fluid = fl; this.base = base; this.amp = amp; this.sea = sea; this.dark = dark;
        }
        Theme fog(int c) { fog = c; return this; }
        Theme stone(IBlockState s) { stone = s; return this; }
    }

    public static final Theme[] ALL = new Theme[20];
    private static IBlockState cc(int m) { return Blocks.CONCRETE.getStateFromMeta(m); }
    private static IBlockState clay(int m) { return Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(m); }
    private static IBlockState grass() { return Blocks.GRASS.getDefaultState(); }
    private static IBlockState dirt() { return Blocks.DIRT.getDefaultState(); }
    private static IBlockState water() { return Blocks.WATER.getDefaultState(); }

    static {
        ALL[0] = new Theme("Karanl\u0131k Evren", BiomeDark.INSTANCE, grass(), dirt(), null, 66, 14, -1, true);
        ALL[1] = new Theme("K\u0131z\u0131l \u00c7\u00f6l", Biomes.MESA, Blocks.SAND.getStateFromMeta(1), Blocks.HARDENED_CLAY.getDefaultState(), null, 66, 12, -1, false);
        ALL[2] = new Theme("Buz Diyar\u0131", Biomes.ICE_PLAINS, Blocks.SNOW.getDefaultState(), Blocks.SNOW.getDefaultState(), Blocks.ICE.getDefaultState(), 66, 10, 62, false);
        ALL[3] = new Theme("Mantar Ad\u0131s\u0131", Biomes.MUSHROOM_ISLAND, Blocks.MYCELIUM.getDefaultState(), dirt(), water(), 64, 8, 60, false);
        ALL[4] = new Theme("Vah\u015fi Orman", Biomes.JUNGLE, grass(), dirt(), water(), 66, 12, 60, false);
        ALL[5] = new Theme("Savan", Biomes.SAVANNA, grass(), dirt(), water(), 66, 8, 60, false);
        ALL[6] = new Theme("Tayga", Biomes.TAIGA, grass(), dirt(), water(), 68, 14, 60, false);
        ALL[7] = new Theme("Lav Diyar\u0131", Biomes.HELL, Blocks.MAGMA.getDefaultState(), Blocks.NETHERRACK.getDefaultState(), Blocks.LAVA.getDefaultState(), 64, 14, 58, false)
                .stone(Blocks.NETHERRACK.getDefaultState()).fog(0x3A0A00);
        ALL[8] = new Theme("Okyanus", Biomes.OCEAN, Blocks.SAND.getDefaultState(), Blocks.SAND.getDefaultState(), water(), 45, 10, 62, false);
        ALL[9] = new Theme("Batakl\u0131k", Biomes.SWAMPLAND, grass(), dirt(), water(), 62, 3, 63, false);
        ALL[10] = new Theme("Da\u011flar", Biomes.EXTREME_HILLS, grass(), dirt(), water(), 90, 45, 63, false);
        ALL[11] = new Theme("End Ta\u015f\u0131 Diyar\u0131", Biomes.PLAINS, Blocks.END_STONE.getDefaultState(), Blocks.END_STONE.getDefaultState(), null, 64, 14, -1, false)
                .stone(Blocks.END_STONE.getDefaultState()).fog(0x1A0030);
        ALL[12] = new Theme("Pembe R\u00fcya", Biomes.PLAINS, clay(6), clay(6), null, 66, 10, -1, false).fog(0xFFB6D9);
        ALL[13] = new Theme("Mor Evren", Biomes.PLAINS, cc(10), cc(10), null, 66, 12, -1, false).fog(0x7A2DBE);
        ALL[14] = new Theme("Mavi Evren", Biomes.PLAINS, cc(11), cc(11), null, 66, 12, -1, false).fog(0x2D5BFF);
        ALL[15] = new Theme("Neon Ye\u015fil", Biomes.PLAINS, cc(5), cc(5), null, 66, 12, -1, false).fog(0x66FF33);
        ALL[16] = new Theme("K\u0131rm\u0131z\u0131 Evren", Biomes.PLAINS, cc(14), cc(14), null, 66, 12, -1, false).fog(0xE02020);
        ALL[17] = new Theme("G\u00fcn Bat\u0131m\u0131", Biomes.PLAINS, clay(1), clay(1), null, 66, 12, -1, false).fog(0xFF9933);
        ALL[18] = new Theme("\u00c7i\u00e7ek Orman\u0131", Biomes.MUTATED_FOREST, grass(), dirt(), water(), 66, 10, 60, false);
        ALL[19] = new Theme("Kum \u00c7\u00f6l\u00fc", Biomes.DESERT, Blocks.SAND.getDefaultState(), Blocks.SAND.getDefaultState(), null, 66, 10, -1, false);
    }

    public static Theme get(int dim) { return ALL[Math.max(0, Math.min(19, dim - DARK_ID))]; }
}

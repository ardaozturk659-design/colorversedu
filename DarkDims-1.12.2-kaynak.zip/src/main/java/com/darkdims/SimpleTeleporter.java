package com.darkdims;

import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.util.ITeleporter;

public class SimpleTeleporter implements ITeleporter {
    private final int dim;
    public SimpleTeleporter(int dim) { this.dim = dim; }

    private static int surface(World w, int x, int z) {
        for (int y = 255; y > 0; y--) {
            Material m = w.getBlockState(new BlockPos(x, y, z)).getMaterial();
            if (m == Material.AIR || m == Material.LEAVES || m == Material.PLANTS || m == Material.VINE || m == Material.SNOW) continue;
            return m == Material.LAVA ? -1 : y;
        }
        return -1;
    }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) {
        double x, y, z; float ry = entity.rotationYaw;
        boolean dark = dim != 0 && Themes.get(dim).dark;
        if (dark) { x = 0.5; y = Castle.G; z = -125.5; ry = 0; }
        else {
            int bx = 0, bz = 0;
            if (dim == 0) { BlockPos sp = world.getSpawnPoint(); bx = sp.getX(); bz = sp.getZ(); }
            int tx = bx, ty = 70;
            for (int i = 0; i < 48; i++) {
                int sy = surface(world, bx + i * 16, bz);
                if (sy > 0) { tx = bx + i * 16; ty = sy; break; }
            }
            x = tx + 0.5; z = bz + 0.5; y = ty + 1;
        }
        entity.setLocationAndAngles(x, y, z, ry, 0);
        entity.motionX = entity.motionY = entity.motionZ = 0;
        entity.fallDistance = 0;
    }
}

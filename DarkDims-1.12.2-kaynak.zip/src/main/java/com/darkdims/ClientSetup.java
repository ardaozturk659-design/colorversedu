package com.darkdims;

import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import org.lwjgl.input.Keyboard;

public class ClientSetup {
    public static KeyBinding KEY;

    public static void preInit() {
        ColorSettings.load();
        RenderingRegistry.registerEntityRenderingHandler(EntityLightningBolt.class, RenderColorBolt::new);
    }

    public static void init() {
        KEY = new KeyBinding("key.darkdims.colors", Keyboard.KEY_B, "key.categories.darkdims");
        ClientRegistry.registerKeyBinding(KEY);
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }
}

package com.darkdims;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ThemedProvider extends WorldProvider {
    public Themes.Theme theme = Themes.ALL[0];

    @Override protected void init() {
        this.hasSkyLight = true;
        theme = Themes.get(getDimension());
        this.biomeProvider = new BiomeProviderSingle(theme.biome);
    }
    @Override public IChunkGenerator createChunkGenerator() { return new ThemedChunkGenerator(world, theme, world.getSeed()); }
    @Override public DimensionType getDimensionType() { return DarkDims.TYPES[Math.max(0, Math.min(19, getDimension() - Themes.DARK_ID))]; }
    @Override public boolean canRespawnHere() { return false; }
    @Override public int getAverageGroundLevel() { return 63; }
    @Override public float calculateCelestialAngle(long t, float p) { return theme.dark ? 0.5F : super.calculateCelestialAngle(t, p); }

    @Override @SideOnly(Side.CLIENT)
    public Vec3d getFogColor(float ca, float pt) {
        if (theme.dark) {
            int c = ColorSettings.sky;
            return new Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
        }
        if (theme.fog < 0) return super.getFogColor(ca, pt);
        float f = MathHelper.clamp(MathHelper.cos(ca * ((float) Math.PI * 2F)) * 2.0F + 0.5F, 0.0F, 1.0F);
        f = f * 0.94F + 0.06F;
        int c = theme.fog;
        return new Vec3d(((c >> 16) & 255) / 255.0 * f, ((c >> 8) & 255) / 255.0 * f, (c & 255) / 255.0 * f);
    }
}

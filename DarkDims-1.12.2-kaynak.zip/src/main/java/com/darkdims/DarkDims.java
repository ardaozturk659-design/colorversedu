package com.darkdims;

import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.*;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = DarkDims.MODID, name = "Dark Dimensions", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class DarkDims {
    public static final String MODID = "darkdims";
    public static final DimensionType[] TYPES = new DimensionType[20];

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        for (int i = 0; i < 20; i++) {
            int id = Themes.DARK_ID + i;
            TYPES[i] = DimensionType.register("darkdims_" + i, "_darkdims_" + i, id, ThemedProvider.class, false);
            DimensionManager.registerDimension(id, TYPES[i]);
        }
        if (e.getSide() == Side.CLIENT) ClientSetup.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        if (e.getSide() == Side.CLIENT) ClientSetup.init();
    }

    @Mod.EventHandler
    public void serverStart(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandBoyut());
    }
}

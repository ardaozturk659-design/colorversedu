package com.darkdims;

import net.minecraft.command.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

public class CommandBoyut extends CommandBase {
    @Override public String getName() { return "boyut"; }
    @Override public String getUsage(ICommandSender s) { return "/boyut <1-20 | geri>"; }
    @Override public int getRequiredPermissionLevel() { return 0; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        EntityPlayerMP p = getCommandSenderAsPlayer(sender);
        if (args.length < 1) {
            StringBuilder sb = new StringBuilder("Evrenler (/boyut <no>, /boyut geri):\n");
            for (int i = 0; i < 20; i++) sb.append(i + 1).append(" = ").append(Themes.ALL[i].name).append("\n");
            sender.sendMessage(new TextComponentString(sb.toString()));
            return;
        }
        int dim; String nm;
        if (args[0].equalsIgnoreCase("geri")) { dim = 0; nm = "Ana D\u00fcnya"; }
        else { int n = parseInt(args[0], 1, 20); dim = Themes.DARK_ID + n - 1; nm = Themes.ALL[n - 1].name; }
        if (p.dimension == dim) throw new CommandException("Zaten buradas\u0131n!");
        p.changeDimension(dim, new SimpleTeleporter(dim));
        p.sendMessage(new TextComponentString("I\u015f\u0131nland\u0131n: " + nm));
    }
}

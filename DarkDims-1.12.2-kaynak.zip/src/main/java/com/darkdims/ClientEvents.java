package com.darkdims;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.world.World;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;

public class ClientEvents {
    private static final IRenderHandler NONE = new IRenderHandler() {
        @Override public void render(float pt, WorldClient w, Minecraft mc) {}
    };

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (ClientSetup.KEY.isPressed()) Minecraft.getMinecraft().displayGuiScreen(new GuiColorSettings());
    }

    @SubscribeEvent
    public void onWorldLoad(WorldEvent.Load e) {
        World w = e.getWorld();
        if (w.isRemote && w.provider instanceof ThemedProvider && ((ThemedProvider) w.provider).theme.dark) {
            w.provider.setSkyRenderer(NONE);
            w.provider.setCloudRenderer(NONE);
        }
    }

    @SubscribeEvent
    public void onFog(EntityViewRenderEvent.FogColors e) {
        World w = Minecraft.getMinecraft().world;
        if (w != null && w.provider instanceof ThemedProvider && ((ThemedProvider) w.provider).theme.dark) {
            int c = ColorSettings.sky;
            e.setRed(((c >> 16) & 255) / 255f);
            e.setGreen(((c >> 8) & 255) / 255f);
            e.setBlue((c & 255) / 255f);
        }
    }
}

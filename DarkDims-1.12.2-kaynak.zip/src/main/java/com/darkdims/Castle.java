package com.darkdims;

import net.minecraft.block.BlockStairs;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;

/** Dev kale: dunya koordinatlarindan blok hesaplar. G=zemin(y=64), W=dis sur yari boyu, K=ana kule yari boyu. */
public class Castle {
    public static final int G = 64, W = 70, K = 26, TR = 9;

    private static IBlockState conc(int m) { return Blocks.CONCRETE.getStateFromMeta(m); }
    private static IBlockState AIR() { return Blocks.AIR.getDefaultState(); }
    private static IBlockState stairs() { return Blocks.STONE_BRICK_STAIRS.getDefaultState().withProperty(BlockStairs.FACING, EnumFacing.EAST); }

    private static IBlockState wall(int x, int y, int z) {
        switch ((x * 7 + y * 13 + z * 5) & 7) {
            case 0: case 1: case 2: return conc(15);
            case 3: case 4: return Blocks.STONEBRICK.getDefaultState();
            case 5: return Blocks.STONEBRICK.getStateFromMeta(2);
            case 6: return Blocks.OBSIDIAN.getDefaultState();
            default: return conc(7);
        }
    }

    private static IBlockState tower(int x, int y, int z, int h, int cx, int cz, int sx, int sz, double d) {
        if (h < 0) {
            if (h == -1) return d <= TR ? (d <= 7 ? conc(7) : Blocks.OBSIDIAN.getDefaultState()) : null;
            return (h >= -6 && d <= TR) ? Blocks.OBSIDIAN.getDefaultState() : null;
        }
        if (h <= 44) {
            if (d <= 7) return h == 17 ? Blocks.STONEBRICK.getDefaultState() : AIR();
            if (d <= TR) {
                int ix = -sx * (x - cx), iz = -sz * (z - cz);
                if ((h <= 3 || (h >= 18 && h <= 21)) && ((ix >= 5 && iz >= 0 && iz <= 2) || (iz >= 5 && ix >= 0 && ix <= 2))) return AIR();
                return wall(x, y, z);
            }
            return null;
        }
        if (h == 45) return d <= TR + 1 ? conc(15) : null;
        if (h <= 66) { double rad = (TR + 1) * (1.0 - (h - 46) / 21.0); return d <= rad ? conc(15) : null; }
        return null;
    }

    private static IBlockState spire(int x, int y, int z, int h, double d) {
        if (h < 0) return null;
        if (h <= 70) return d <= 6 ? wall(x, y, z) : null;
        if (h <= 96) { double rad = 7 * (1.0 - (h - 71) / 26.0); return d <= rad ? conc(15) : null; }
        return null;
    }

    public static IBlockState at(int x, int y, int z) {
        int h = y - G, ax = Math.abs(x), az = Math.abs(z), m = Math.max(ax, az);
        if (h < -6) return null;
        if (m > W + 10) {
            if (z < 0 && ax <= 2 && az <= 125 && h == -1) return conc(7);
            return null;
        }
        IBlockState s;
        for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) {
            int cx = sx * W, cz = sz * W;
            double d = Math.hypot(x - cx, z - cz);
            if (d <= TR + 1) { s = tower(x, y, z, h, cx, cz, sx, sz, d); if (s != null) return s; }
            d = Math.hypot(x - sx * K, z - sz * K);
            if (d <= 7) { s = spire(x, y, z, h, d); if (s != null) return s; }
        }
        // dis sur
        if (m >= W - 3 && m <= W) {
            if (z < 0 && az >= W - 3 && ax <= 4 && h >= 0 && h <= 9 && (ax <= 3 || h <= 7)) return AIR();
            if (h >= 0 && h <= 17) return wall(x, y, z);
            if (h >= 18 && h <= 19 && m == W && ((x + z) & 1) == 0) return conc(15);
            if (h == 18 && m == W - 2 && ((ax > az && Math.floorMod(z, 12) == 0) || (az >= ax && Math.floorMod(x, 12) == 0)))
                return Blocks.TORCH.getDefaultState();
            return null;
        }
        // hendek + kopru
        if (m >= W + 3 && m <= W + 10) {
            boolean bridge = z < 0 && ax <= 3;
            if (h == -1) return bridge ? Blocks.PLANKS.getStateFromMeta(5) : AIR();
            if (h >= -5 && h <= -2) return Blocks.LAVA.getDefaultState();
            if (h == -6) return Blocks.OBSIDIAN.getDefaultState();
            return null;
        }
        // surun ic tarafindan sur ustune merdiven
        if (z >= -66 && z <= -65 && x >= 6 && x <= 23) {
            int i = x - 6;
            if (h == i) return stairs();
            if (h >= 0 && h < i) return wall(x, y, z);
        }
        // ana kule
        if (m <= K) {
            if (h == 60 || h == 61) return (m == K && ((x + z) & 1) == 0) ? conc(15) : null;
            if (h >= 0 && h <= 59) {
                if (m >= K - 2) {
                    if (z < 0 && az >= K - 2 && ax <= 4 && h <= 9 && (ax <= 3 || h <= 7)) return AIR();
                    int fh = Math.floorMod(h, 15);
                    if (fh >= 5 && fh <= 8) {
                        if (az >= ax ? (Math.floorMod(x, 6) == 0 && ax <= K - 4) : (Math.floorMod(z, 6) == 0 && az <= K - 4)) return AIR();
                    }
                    return wall(x, y, z);
                }
                if (z >= 17 && z <= 19 && x >= -20 && x <= -6) {
                    int i = x + 20;
                    for (int k = 0; k < 4; k++) {
                        if (h == 15 * k + i) return stairs();
                        if (h >= 15 * k && h < 15 * k + i) return Blocks.STONEBRICK.getDefaultState();
                    }
                }
                if (Math.floorMod(h + 1, 15) == 0) {
                    if (x >= -10 && x <= -6 && z >= 17 && z <= 19) return AIR();
                    if (Math.floorMod(x, 8) == 4 && Math.floorMod(z, 8) == 4) return Blocks.GLOWSTONE.getDefaultState();
                    return conc(7);
                }
                return AIR();
            }
        }
        // avlu
        if (m <= W - 4) {
            if (h == -1) return conc((((x >> 3) + (z >> 3)) & 1) == 0 ? 15 : 7);
            if (h >= 0 && h <= 3 && m >= K + 6 && Math.floorMod(x, 16) == 8 && Math.floorMod(z, 16) == 8)
                return h < 3 ? Blocks.OBSIDIAN.getDefaultState() : Blocks.GLOWSTONE.getDefaultState();
        }
        return null;
    }
}

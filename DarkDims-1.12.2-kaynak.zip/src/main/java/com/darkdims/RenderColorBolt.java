package com.darkdims;

import java.util.Random;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.util.ResourceLocation;

public class RenderColorBolt extends Render<EntityLightningBolt> {
    public RenderColorBolt(RenderManager rm) { super(rm); }

    @Override
    public void doRender(EntityLightningBolt e, double x, double y, double z, float yaw, float pt) {
        int c = ColorSettings.lightning;
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        Random rnd = new Random(e.boltVertex);
        double[] ox = new double[9], oz = new double[9];
        double cx = 0, cz = 0;
        for (int i = 8; i >= 0; i--) { ox[i] = cx; oz[i] = cz; cx += rnd.nextInt(11) - 5; cz += rnd.nextInt(11) - 5; }
        float[] w = {0.12f, 0.3f, 0.55f, 0.9f};
        for (int l = 0; l < 4; l++) {
            bb.begin(7, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < 8; i++) {
                double y0 = y + i * 16, y1 = y + (i + 1) * 16, ww = w[l];
                bb.pos(x + ox[i] - ww, y0, z + oz[i]).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i] + ww, y0, z + oz[i]).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i + 1] + ww, y1, z + oz[i + 1]).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i + 1] - ww, y1, z + oz[i + 1]).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i], y0, z + oz[i] - ww).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i], y0, z + oz[i] + ww).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i + 1], y1, z + oz[i + 1] + ww).color(r, g, b, 0.3f).endVertex();
                bb.pos(x + ox[i + 1], y1, z + oz[i + 1] - ww).color(r, g, b, 0.3f).endVertex();
            }
            t.draw();
        }
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
    }

    @Override public boolean shouldRender(EntityLightningBolt e, ICamera cam, double cx, double cy, double cz) { return true; }
    @Override protected ResourceLocation getEntityTexture(EntityLightningBolt e) { return null; }
}

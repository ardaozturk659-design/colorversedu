package com.darkdims;

import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.client.config.GuiSlider;

public class GuiColorSettings extends GuiScreen implements GuiSlider.ISlider {
    private static final String[] NAMES = {"\u00c7imen Rengi", "Y\u0131ld\u0131r\u0131m Rengi", "G\u00f6ky\u00fcz\u00fc Rengi"};
    private static final int[] PRESETS = {0x000000, 0x2B2B2B, 0x555555, 0xAAAAAA, 0xFFFFFF, 0xFF0000, 0xFF8800,
            0xFFFF00, 0x00FF00, 0x00FFFF, 0x3366FF, 0xAA00FF, 0xFF66CC};
    private int sel = 0;
    private GuiSlider sr, sg, sb;
    private boolean grassChanged = false;

    @Override
    public void initGui() {
        buttonList.clear();
        sr = sg = sb = null;
        int cx = width / 2;
        for (int i = 0; i < 3; i++) addButton(new GuiButton(i, cx - 150, 40 + i * 24, 130, 20, (i == sel ? "> " : "") + NAMES[i]));
        int c = ColorSettings.get(sel);
        GuiSlider a = new GuiSlider(10, cx - 10, 40, 150, 20, "K\u0131rm\u0131z\u0131: ", "", 0, 255, (c >> 16) & 255, false, true, this);
        GuiSlider b = new GuiSlider(11, cx - 10, 64, 150, 20, "Ye\u015fil: ", "", 0, 255, (c >> 8) & 255, false, true, this);
        GuiSlider d = new GuiSlider(12, cx - 10, 88, 150, 20, "Mavi: ", "", 0, 255, c & 255, false, true, this);
        addButton(a); addButton(b); addButton(d);
        sr = a; sg = b; sb = d;
        addButton(new GuiButton(20, cx - 150, 130, 130, 20, "S\u0131f\u0131rla"));
        addButton(new GuiButton(21, cx - 10, 130, 150, 20, "Kaydet ve Kapat"));
    }

    @Override
    public void onChangeSliderValue(GuiSlider s) {
        if (sr == null || sg == null || sb == null) return;
        ColorSettings.set(sel, (sr.getValueInt() << 16) | (sg.getValueInt() << 8) | sb.getValueInt());
        if (sel == 0) grassChanged = true;
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        if (b.id < 3) { sel = b.id; initGui(); }
        else if (b.id == 20) { ColorSettings.set(sel, ColorSettings.def(sel)); if (sel == 0) grassChanged = true; initGui(); }
        else if (b.id == 21) mc.displayGuiScreen(null);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        int cx = width / 2;
        for (int i = 0; i < PRESETS.length; i++) {
            int x = cx - 150 + i * 24, y = 200;
            if (mx >= x && mx < x + 20 && my >= y && my < y + 20) {
                ColorSettings.set(sel, PRESETS[i]);
                if (sel == 0) grassChanged = true;
                initGui();
            }
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        int cx = width / 2;
        drawCenteredString(fontRenderer, "Renk Ayarlar\u0131 (B)", cx, 15, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
        for (int i = 0; i < 3; i++) drawRect(cx - 46, 42 + i * 24, cx - 24, 58 + i * 24, 0xFF000000 | ColorSettings.get(i));
        int c = ColorSettings.get(sel);
        drawRect(cx - 150, 160, cx + 150, 190, 0xFF000000 | c);
        int luma = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
        drawCenteredString(fontRenderer, String.format("%s  #%06X", NAMES[sel], c), cx, 170, luma < 128 ? 0xFFFFFF : 0x000000);
        for (int i = 0; i < PRESETS.length; i++) {
            int x = cx - 150 + i * 24;
            drawRect(x - 1, 199, x + 21, 221, 0xFFFFFFFF);
            drawRect(x, 200, x + 20, 220, 0xFF000000 | PRESETS[i]);
        }
        drawCenteredString(fontRenderer, "\u00c7imen ve g\u00f6ky\u00fcz\u00fc: Karanl\u0131k Evren'de ge\u00e7erli", cx, 232, 0xAAAAAA);
    }

    @Override public boolean doesGuiPauseGame() { return false; }

    @Override
    public void onGuiClosed() {
        ColorSettings.save();
        if (grassChanged && mc.renderGlobal != null && mc.world != null) mc.renderGlobal.loadRenderers();
    }
}

package com.darkdims;

import java.io.*;
import java.util.Properties;
import net.minecraftforge.fml.common.Loader;

public class ColorSettings {
    public static final int DEF_GRASS = 0x2B2B2B, DEF_LIGHTNING = 0xCCCCFF, DEF_SKY = 0x000000;
    public static volatile int grass = DEF_GRASS, lightning = DEF_LIGHTNING, sky = DEF_SKY;

    public static int get(int i) { return i == 0 ? grass : i == 1 ? lightning : sky; }
    public static int def(int i) { return i == 0 ? DEF_GRASS : i == 1 ? DEF_LIGHTNING : DEF_SKY; }
    public static void set(int i, int c) {
        c &= 0xFFFFFF;
        if (i == 0) grass = c; else if (i == 1) lightning = c; else sky = c;
    }
    private static File file() { return new File(Loader.instance().getConfigDir(), "darkdims_colors.properties"); }

    public static void load() {
        try (InputStream in = new FileInputStream(file())) {
            Properties p = new Properties();
            p.load(in);
            grass = Integer.parseInt(p.getProperty("grass", "" + DEF_GRASS));
            lightning = Integer.parseInt(p.getProperty("lightning", "" + DEF_LIGHTNING));
            sky = Integer.parseInt(p.getProperty("sky", "" + DEF_SKY));
        } catch (Exception ignored) {}
    }

    public static void save() {
        try (OutputStream out = new FileOutputStream(file())) {
            Properties p = new Properties();
            p.setProperty("grass", "" + grass);
            p.setProperty("lightning", "" + lightning);
            p.setProperty("sky", "" + sky);
            p.store(out, "DarkDims colors");
        } catch (Exception ignored) {}
    }
}

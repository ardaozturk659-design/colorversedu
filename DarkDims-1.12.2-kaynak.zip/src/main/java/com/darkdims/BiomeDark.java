package com.darkdims;

import net.minecraft.entity.monster.*;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;

public class BiomeDark extends Biome {
    public static final BiomeDark INSTANCE = new BiomeDark();

    private BiomeDark() {
        super(new Biome.BiomeProperties("Dark Universe").setBaseHeight(0.1F).setHeightVariation(0.2F)
                .setTemperature(0.5F).setRainfall(0.5F).setWaterColor(0x0A0A0A));
        this.topBlock = Blocks.GRASS.getDefaultState();
        this.fillerBlock = Blocks.DIRT.getDefaultState();
        this.decorator.treesPerChunk = 1;
        this.decorator.flowersPerChunk = 0;
        this.decorator.grassPerChunk = 6;
        this.spawnableMonsterList.add(new Biome.SpawnListEntry(EntityZombie.class, 100, 3, 4));
        this.spawnableMonsterList.add(new Biome.SpawnListEntry(EntitySkeleton.class, 100, 3, 4));
        this.spawnableMonsterList.add(new Biome.SpawnListEntry(EntitySpider.class, 60, 2, 3));
        this.spawnableMonsterList.add(new Biome.SpawnListEntry(EntityCreeper.class, 50, 1, 2));
    }

    @Override public int getGrassColorAtPos(BlockPos pos) { return ColorSettings.grass; }
    @Override public int getFoliageColorAtPos(BlockPos pos) { return ColorSettings.grass; }
    @Override public int getSkyColorByTemp(float t) { return ColorSettings.sky; }
}

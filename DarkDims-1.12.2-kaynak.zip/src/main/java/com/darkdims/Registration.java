package com.darkdims;

import net.minecraft.world.biome.Biome;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = DarkDims.MODID)
public class Registration {
    @SubscribeEvent
    public static void biomes(RegistryEvent.Register<Biome> e) {
        e.getRegistry().register(BiomeDark.INSTANCE.setRegistryName(DarkDims.MODID, "dark_universe"));
    }
}

package com.darkdims;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldEntitySpawner;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.NoiseGeneratorPerlin;

public class ThemedChunkGenerator implements IChunkGenerator {
    private final World world; private final Themes.Theme theme; private final Random rand;
    private final NoiseGeneratorPerlin n1, n2; private final byte biomeId;

    public ThemedChunkGenerator(World w, Themes.Theme t, long seed) {
        world = w; theme = t; rand = new Random(seed);
        n1 = new NoiseGeneratorPerlin(new Random(seed), 4);
        n2 = new NoiseGeneratorPerlin(new Random(seed + 17), 3);
        biomeId = (byte) Biome.getIdForBiome(t.biome);
    }

    private static double clamp(double v) { return Math.max(-1, Math.min(1, v)); }

    private int height(int x, int z) {
        double a = clamp(n1.getValue(x * 0.006, z * 0.006) / 2.0);
        double b = clamp(n2.getValue(x * 0.04, z * 0.04) / 3.0);
        double h = theme.base + a * theme.amp + b * 2.5;
        if (theme.dark) {
            int m = Math.max(Math.abs(x), Math.abs(z));
            double t = Math.max(0, Math.min(1, (m - 130) / 60.0));
            t = t * t * (3 - 2 * t);
            h = 63 + (h - 63) * t;
        }
        return (int) Math.round(h);
    }

    @Override public Chunk generateChunk(int cx, int cz) {
        ChunkPrimer p = new ChunkPrimer();
        IBlockState bedrock = Blocks.BEDROCK.getDefaultState();
        for (int lx = 0; lx < 16; lx++) for (int lz = 0; lz < 16; lz++) {
            int wx = cx * 16 + lx, wz = cz * 16 + lz;
            int h = height(wx, wz);
            for (int y = 0; y <= h; y++)
                p.setBlockState(lx, y, lz, y == 0 ? bedrock : y == h ? theme.top : y >= h - 3 ? theme.filler : theme.stone);
            if (theme.fluid != null) for (int y = h + 1; y <= theme.sea; y++) p.setBlockState(lx, y, lz, theme.fluid);
            if (theme.dark && Math.abs(wx) <= 140 && Math.abs(wz) <= 140) {
                for (int y = Castle.G - 7; y <= Castle.G + 100; y++) {
                    IBlockState s = Castle.at(wx, y, wz);
                    if (s != null) p.setBlockState(lx, y, lz, s);
                }
            }
        }
        Chunk c = new Chunk(world, p, cx, cz);
        Arrays.fill(c.getBiomeArray(), biomeId);
        c.generateSkylightMap();
        return c;
    }

    @Override public void populate(int x, int z) {
        BlockFalling.fallInstantly = true;
        int i = x * 16, j = z * 16;
        BlockPos pos = new BlockPos(i, 0, j);
        Biome b = world.getBiome(pos.add(16, 0, 16));
        rand.setSeed(world.getSeed());
        long k = rand.nextLong() / 2L * 2L + 1L, l = rand.nextLong() / 2L * 2L + 1L;
        rand.setSeed((long) x * k + (long) z * l ^ world.getSeed());
        b.decorate(world, rand, pos);
        WorldEntitySpawner.performWorldGenSpawning(world, b, i + 8, j + 8, 16, 16, rand);
        BlockFalling.fallInstantly = false;
    }

    @Override public boolean generateStructures(Chunk c, int x, int z) { return false; }
    @Override public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType t, BlockPos pos) { return world.getBiome(pos).getSpawnableList(t); }
    @Override public BlockPos getNearestStructurePosition(World w, String n, BlockPos p, boolean f) { return null; }
    @Override public void recreateStructures(Chunk c, int x, int z) {}
    @Override public boolean isInsideStructure(World w, String n, BlockPos p) { return false; }
}

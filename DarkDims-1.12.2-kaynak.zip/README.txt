DarkDims - Minecraft 1.12.2 Forge modu (kaynak kod)

KURULUM
1) Forge 1.12.2 MDK indir (14.23.5.2860): files.minecraftforge.net
2) MDK klasorundeki "src" klasorunu sil, bu zip'teki "src" klasorunu koy.
3) MDK klasorunde:  gradlew build   (Java 8 gerekir)
4) build/libs/ icindeki .jar dosyasini mods klasorune at.

KULLANIM
- /boyut           -> 20 evrenin listesi
- /boyut 1         -> Karanlik Evren (kale)   /boyut 2..20 -> diger evrenler
- /boyut geri      -> Ana dunya
- B tusu           -> Renk ayarlari (cimen / yildirim / gokyuzu)
- Yildirim denemek icin: /summon lightning_bolt
